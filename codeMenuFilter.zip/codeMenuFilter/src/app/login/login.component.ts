import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  uname: string = '';
  pass: string = '';
  count: number = 0;
  errormsgC : boolean = false;
  errormsg:string ;

  constructor(private router: Router) { }

  ngOnInit() {
    localStorage.setItem('username', '');
  }

  login() {

    if (this.count < 3  ) {
      if (this.uname == '' || this.uname !== 'admin') {
        this.errormsgC = true;
        this.errormsg = "username incorrect";
      } else if (this.pass == '' || this.pass !== 'admin') {
        this.errormsgC = true;
        this.errormsg = "password incorrect";
      } else {
        this.errormsgC = true;
        this.errormsg = "login success";
        localStorage.setItem('username', this.uname);
        this.router.navigate(["home"]);
      }
      this.count++;
    } else {
      localStorage.setItem('username', '');
      this.pass == null;
        this.errormsgC = true;
        this.errormsg = "your account has been locked please, reset it !";
    }

  }

  resetPass(){
    localStorage.setItem('username', '');
    this.count = 0;
    this.errormsg = 'password unlocked';
  }

  resetError(){
    this.errormsgC = false;
  }
}
